package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.model.CalculatorService;
@Service
public class AppService {

	
	@Autowired
	@Qualifier(value = "savingAccount")
	private CalculatorService calculatorService;

	public CalculatorService getCalculatorService() {
		return calculatorService;
	}

	public void setCalculatorService(CalculatorService calculatorService) {
		this.calculatorService = calculatorService;
	}
	
	
	public double service(double amount) {
		return calculatorService.calculate(amount);
	}
	
}
