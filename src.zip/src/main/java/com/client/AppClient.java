package com.client;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.service.AppService;

public class AppClient {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx= new AnnotationConfigApplicationContext(AppConfig.class);
		
		AppService service=(AppService)ctx.getBean("appService");
		
		System.out.println(service.service(2345));

	}

}
