package com.example.amdspringcore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@SpringBootApplication
public class AmdspringcoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmdspringcoreApplication.class, args);
	}

}
