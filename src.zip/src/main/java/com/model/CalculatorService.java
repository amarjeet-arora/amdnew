package com.model;

public interface CalculatorService {
	
	public double calculate(double amount);

}
