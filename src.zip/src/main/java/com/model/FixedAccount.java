package com.model;

import org.springframework.stereotype.Component;

@Component
public class FixedAccount implements CalculatorService{
	
	private double roi=5.5;
	private int duration= 6;

	@Override
	public double calculate(double amount) {
		// TODO Auto-generated method stub
		return amount*roi/duration;
	}

	public double getRoi() {
		return roi;
	}

	public void setRoi(double roi) {
		this.roi = roi;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

}
