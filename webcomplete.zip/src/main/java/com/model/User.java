package com.model;

public class User {
	
	
	
	private String uName;
	private String city;
	private String password;
	private String email;
	public User(String uName, String city, String password, String email) {
		super();
		this.uName = uName;
		this.city = city;
		this.password = password;
		this.email = email;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "User [uName=" + uName + ", city=" + city + ", password=" + password + ", email=" + email + "]";
	}
	
	

}
