package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.model.User;

@Service
public class UserDao {
	
	private List<User> list= new ArrayList<User>();
	
	
	public boolean validUser(String uname,String pass) {
		
		if(uname.equals("admin")&& pass.equals("manager")) {
			
			return true;
		}
		else {
			return false;
		}
	}
	
	
	public boolean addUser(User user) {
		
		list.add(user);
		System.out.println(list);
		
		return true;
		
	}
	
	
	

}
