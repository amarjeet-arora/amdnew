package com.example.amdspringcore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmdspringcoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
