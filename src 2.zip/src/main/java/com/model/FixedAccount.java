package com.model;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

 

public class FixedAccount implements CalculatorService{
	
	private double roi;
	private int duration;

	@Override
	public double calculate(double amount) {
		// TODO Auto-generated method stub
		return amount*roi/duration;
	}

	public FixedAccount(double roi, int duration) {
		super();
		this.roi = roi;
		this.duration = duration;
	}

	 

}
