package com.service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.model.CalculatorService;
 
 public class AppService {

	
	 
	private CalculatorService calculatorService;

	 
	
	
	public double service(double amount) {
		return calculatorService.calculate(amount);
	}




	public AppService(CalculatorService calculatorService) {
		super();
		this.calculatorService = calculatorService;
	}
	 
	
}
