package com.client;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.service.AppService;

public class AppClient {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx= new AnnotationConfigApplicationContext(AppConfig.class);
		
		AppService service=(AppService)ctx.getBean("appService");
		
		AppService service2=(AppService)ctx.getBean("appService");
System.out.println(service.service(2345));
		
		//System.out.println(service.hashCode());
		//System.out.println(service.hashCode());
		
		ctx.close();


	}

}
