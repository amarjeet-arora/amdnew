package com.client;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.model.FixedAccount;
import com.model.SavingAccount;
import com.service.AppService;

@Configuration

public class AppConfig {
	
	
	@Bean
	public FixedAccount fixedAccount() {
		return new FixedAccount(4.5, 3);
	}
	@Bean
	
	public SavingAccount savingAccount() {
		return new SavingAccount(5.5, 7);
	}
	
	@Bean
	public AppService appService() {
		return new AppService(fixedAccount());
	}
	
	

}
