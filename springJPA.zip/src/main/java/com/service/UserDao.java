package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.User;

@Service
public class UserDao {
	
	//private List<User> list= new ArrayList<User>();
	
	
	@Autowired
	private com.dao.UserDaoRepo userDaoRepo;
	
	public boolean validUser(String uname,String pass) {
		
		if(uname.equals("admin")&& pass.equals("manager")) {
			
			return true;
		}
		else {
			return false;
		}
	}
	
	
	public boolean addUser(User user) {
		
		userDaoRepo.save(user);
		 
		return true;
		
	}
	 
	
	

}
