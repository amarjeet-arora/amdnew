package com.aspects;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;
@Component
@Aspect
public class MyAspect {
	
	
	
	
	
	@Before("execution (* com.model.Welcome.sayWelcome(..))")
	public void callBefore() {
		System.out.println("i am called before");
	}

}
