package com.client;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.model.Welcome;

 
public class AppClient {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx= new AnnotationConfigApplicationContext(AppConfig.class);
		
		 Welcome welcome=(Welcome)ctx.getBean("welcomeImpl");
		System.out.println(welcome.sayWelcome("Amdocs"));
		ctx.close();


	}

}
