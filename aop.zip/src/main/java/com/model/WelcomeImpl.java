package com.model;

import org.springframework.stereotype.Component;

@Component
public class WelcomeImpl implements Welcome{

	@Override
	public String sayWelcome(String name) {
		// TODO Auto-generated method stub
		return "Welcome " + name;
	}

}
