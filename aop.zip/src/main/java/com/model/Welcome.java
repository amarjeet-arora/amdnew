package com.model;

public interface Welcome {
	
	public String sayWelcome(String name);

}
