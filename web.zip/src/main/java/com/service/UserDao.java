package com.service;

import org.springframework.stereotype.Service;

@Service
public class UserDao {
	
	
	
	
	public boolean validUser(String uname,String pass) {
		
		if(uname.equals("admin")&& pass.equals("manager")) {
			
			return true;
		}
		else {
			return false;
		}
	}

}
