package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.service.UserDao;
@Controller
@RequestMapping("/mainapp")
public class AppController {
	
	@Autowired
	private UserDao userDao;
	
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	@PostMapping("/login")
	@ResponseBody
	public String loginValidate(@RequestParam("uname")String name,@RequestParam("pass")String pass) {
		
		if(userDao.validUser(name, pass)) {
			return "user is validated";
		}
		
		return "login failed";
	}
	
	

}